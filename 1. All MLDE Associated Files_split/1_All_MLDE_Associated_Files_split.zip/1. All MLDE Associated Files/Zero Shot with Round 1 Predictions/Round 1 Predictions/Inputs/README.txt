Sequence Only input files are too large to upload consistently. 

They are a .csv file type. 
File structure is a column with the 4 letter designation for each mutant followed by 3072 columns containing the MSA Transformer embedding for that mutant. 
Column headers are "id" above the 4 letter designation and "MSA1" through "MSA3072" for each column of MSA Transformer Embedding. 